  <footer class="site-footer">
            <div class="footer-inner bg-white">
                <div class="row">
                   
                    <div class="col-sm-12 text-center">
                        Vehicle Parking Management System
                    </div>
                </div>
            </div>
        </footer>